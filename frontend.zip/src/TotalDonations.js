import React, { useEffect, useState } from 'react';
import axios from './api'; // Adjust the import path as needed
import LoadingSpinner from './LoadingSpinner';

const TotalDonations = () => {
  const [totalDonations, setTotalDonations] = useState(0);
  const [displayedDonations, setDisplayedDonations] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchTotalDonations = async () => {
      try {
        const response = await axios.get('/api/donation/GetTotalDonations'); 
        if (response.data && typeof response.data === 'number') {
          setTotalDonations(parseInt(response.data)*55);
        } else {
          throw new Error('Unexpected response format');
        }
      } catch (err) {
        console.error('Error fetching total donations:', err);
        setError('Error fetching total donations');
      } finally {
        setLoading(false);
      }
    };

    fetchTotalDonations();
  }, []);

  useEffect(() => {
    if (!loading && totalDonations > 0) {
      let start = 0;
      const duration = 2000; // Duration of the animation in milliseconds
      const increment = totalDonations / (duration / 10);

      const counter = setInterval(() => {
        start += increment;
        if (start >= totalDonations) {
          setDisplayedDonations(totalDonations);
          clearInterval(counter);
        } else {
          setDisplayedDonations(Math.ceil(start));
        }
      }, 10);

      return () => clearInterval(counter);
    }
  }, [loading, totalDonations]);

  if (loading) {
    <LoadingSpinner />;
  }

  if (error) {
    return <div>{error}</div>;
  }

  return (
    <div className="h-64 p-6 text-center">
      <h2 className="md:text-6xl text-2xl font-bold text-gray-800 m-6">Total Donations <span className=' text-blue-600'>so far</span></h2>
      <p className="md:text-4xl text-xl font-semibold text-gray-700">{displayedDonations.toLocaleString()} ETB</p>
    </div>
  );
};

export default TotalDonations;
