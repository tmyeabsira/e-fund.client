import { Link } from "react-router-dom";
import NavbarII from "./NavbarII";
import CurrencyInputForm from "./CurrencyInputForm";
import SearchDropdown from "./SearchDropdown";
import homepic from './images/homepic.jpg';
import hand from './images/blue.png'
import React, { useEffect, useRef, useState } from 'react';
import axios from './api'; 
import FundraiserCard from './FundraiserCard'; 
import myImage from './images/together.webp'
import TotalDonations from "./TotalDonations";

const Home = () => {
  return (
    <div>
      <HeroSection />
      <Howitworks />
      <FundraisersSection />
    </div>
  );
}

const HeroSection = () => {
  const handleButtonClick = (e) => {
    e.preventDefault();
    document.getElementById('target-section').scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section className="bg-white dark:bg-gray-900">
      
      <div className="grid max-w-screen-xl px-4 py-8 mx-auto lg:gap-8 xl:gap-0 lg:py-16 lg:grid-cols-12">
        <div className="mr-auto place-self-center lg:col-span-7">
          <h1 className="max-w-2xl mb-4 text-4xl font-extrabold tracking-tight leading-none md:text-5xl xl:text-6xl dark:text-white">
          Where Every Contribution Counts.
          </h1>
          <p className="max-w-2xl mb-6 font-light text-gray-500 lg:mb-8 md:text-lg lg:text-xl dark:text-gray-400">
          E-fund is a dedicated crowdfunding platform that connects generous donors with inspiring Ethiopian projects, enabling impactful community-driven development and change.
          </p>
          <button
            onClick={handleButtonClick}
            className="inline-flex items-center justify-center px-5 py-3 mr-3 text-base font-medium text-center text-white rounded-lg bg-primary-700 hover:bg-primary-800 focus:ring-4 focus:ring-primary-300 dark:focus:ring-primary-900"
          >
            Get started
            <svg
              className="w-5 h-5 ml-2 -mr-1"
              fill="currentColor"
              viewBox="0 0 20 20"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                fillRule="evenodd"
                d="M10.293 3.293a1 1 0 011.414 0l6 6a1 1 0 010 1.414l-6 6a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-4.293-4.293a1 1 0 010-1.414z"
                clipRule="evenodd"
              ></path>
            </svg>
          </button>
        </div>
        <div className="hidden lg:mt-0 lg:col-span-5 lg:flex">
          <img
            src="https://flowbite.s3.amazonaws.com/blocks/marketing-ui/hero/phone-mockup.png"
            alt="homepage"
          />
        </div>
      </div>
      
      <TotalDonations />
        <div className="flex flex-col items-center justify-center w-full h-full px-8 py-6 mx-auto text-sm text-gray-500 dark:text-gray-400 md:grid-cols-3 md:px-6">
      <div className="flex flex-col h-full items-center justify-center px-4 py-2 mx-auto lg:gap-8 xl:gap-0 lg:py-2">
        </div>
        <div className="my-3 grid max-w-screen-xl px-4 py-8 mx-auto lg:gap-8 xl:gap-0 lg:py-16 lg:grid-cols-12">
          <div className="mr-auto place-self-center lg:col-span-7">
            <h1 className="max-w-2xl mb-4 text-4xl font-serif font-extrabold tracking-tight leading-none md:text-5xl xl:text-6xl dark:text-white">
              Start a <span style={{ color: '#0a66c2' }}>Fund</span>, Change a Life: Your Impact Begins Here
            </h1>
            <p className="max-w-2xl mt-3 mb-6 font-light text-gray-500 lg:mb-8 md:text-lg lg:text-xl dark:text-gray-400">
              Welcome to our Fundraising Platform, where your initiative can spark real change in the world. Whether you're passionate about education, healthcare, environmental conservation, or community development, starting a fund in any of these categories can make a significant difference.
            </p>
            <Link to={'/create/fundraiser/category'} className="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 me-2 mb-2 dark:bg-blue-600 dark:hover:bg-blue-700 focus:outline-none dark:focus:ring-blue-800">
              Start a Fundraiser
            </Link>
          </div>
          <div className="lg:mt-0 lg:col-span-5 lg:flex">
            <img src={hand} alt="mockup" className="w-full h-auto md:w-3/4 lg:w-full"/>
          </div>
        </div>
      </div>
    </section>
  );
};

const Howitworks = () => {
  const sectionRef = useRef(null);
  const textRef = useRef(null);

  useEffect(() => {
    const section = sectionRef.current;
    const text = textRef.current;

    const handleScroll = (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          section.classList.add('animate-stretch');
          text.classList.add('animate-slide-up');
        }
      });
    };

    const observer = new IntersectionObserver(handleScroll, {
      threshold: 0.5,
    });

    observer.observe(section);

    return () => {
      observer.unobserve(section);
    };
  }, []);

  return (
    <div className="w-full py-32 bg-gray-700 flex items-center justify-center">
    <section
      ref={sectionRef}
      className="w-4/5 mx-auto py-12 transition-all duration-1000 ease-in-out transform origin-center"
    >
      <div ref={textRef} className="max-w-5xl mx-auto  opacity-0 translate-y-10 transition-all duration-1000 ease-in-out">
        <h2 className="md:text-5xl text-3xl font-bold text-gray-900 mb-12">
          Fundraising on OurPlatform is easy, powerful, and trusted.
        </h2>
        <p className="md:text-2xl text-lg text-white mb-9">
          Get what you need to help your fundraiser succeed on OurPlatform, whether you’re raising money for yourself, friends, family, or charity. With no fee to start, OurPlatform is the world’s leading crowdfunding platform—from memorial tributes and funerals to medical emergencies and nonprofits. Whenever you need help, you can ask here.
        </p>
        <p className="md:text-2xl text-lg text-white">
          Still have questions? Learn more about how OurPlatform works.
        </p>
      </div>
    </section>
    </div>
  );
};

const FundraisersSection = () => {
  const [fundraisers, setFundraisers] = useState([]);
  
  useEffect(() => {
    const fetchFundraisers = async () => {
      try {
        const response = await axios.get('/api/Fundraiser/GetAllFundraisers');
        setFundraisers(response.data.$values);
      } catch (error) {
        console.error('Error fetching fundraisers', error);
      }
    };

    fetchFundraisers();
  }, []);
  
  return (
    <section id="target-section" className="bg-white py-8 sm:py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-2xl sm:text-3xl font-bold text-gray-800 mb-4 sm:mb-8">
          Discover fundraisers inspired by what you care about
        </h2>
        <div className="flex justify-between items-center mb-4 sm:mb-8">
          <div>
            <button className="px-4 py-2 bg-gray-200 text-gray-700 rounded-full">Happening worldwide</button>
          </div>
          <div className="flex space-x-2">
            <button className="p-2 bg-gray-200 text-gray-700 rounded-full">←</button>
            <button className="p-2 bg-gray-200 text-gray-700 rounded-full">→</button>
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {fundraisers.map(fundraiser => (
            <FundraiserCard key={fundraiser.id} fundraiser={fundraiser} />
          ))}    
        </div> 
      </div>
    </section>
  );
};

export default Home;
